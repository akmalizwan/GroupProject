﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Optimization;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assigment2
{
    public partial class SignInPage : System.Web.UI.Page
    {
        

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void txtName_TextChanged(object sender, EventArgs e)
        {

        }

        protected HttpResponse GetResponse()
        {
            return Response;
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                // Process the form data
                string name = txtName.Text;
                string email = txtEmail.Text;
                string phone = txtPhone.Text;

                // You can perform further actions with the collected data, such as saving to a database, sending an email, etc.

                // Display a popup message using JavaScript
                string script = $"alert('Thank you, {name}, for submitting the form!');";
                ClientScript.RegisterStartupScript(this.GetType(), "Popup", script, true);
            }
        }

    }
}